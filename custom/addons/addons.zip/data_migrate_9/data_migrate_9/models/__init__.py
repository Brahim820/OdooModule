# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import data_migrate
import business_logic
import jobs_main_data
import jobs_sale
import jobs_invoice
import jobs_purchase
import jobs_employees
import jobs_dosar
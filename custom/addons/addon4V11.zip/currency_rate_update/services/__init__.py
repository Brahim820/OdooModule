# Note, that CA_BOC getter seems not to be working
from . import update_service_CA_BOC
from . import update_service_CH_ADMIN
from . import update_service_ECB
from . import update_service_YAHOO
from . import update_service_PL_NBP
from . import update_service_MX_BdM
from . import update_service_RO_BNR
from . import update_service_VN_VCB
